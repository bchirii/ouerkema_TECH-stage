(function ($) {
    $(document).ready(function () {
        $('.single-stm_popups #header, .single-stm_popups .page_title, .single-stm_popups #footer').remove();
    });
})(jQuery);