<?php if ( is_active_sidebar( 'footer' ) ) { ?>

	<?php dynamic_sidebar( 'shop' ); ?>

<?php } ?>