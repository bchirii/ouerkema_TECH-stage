<div class="post_details_wr <?php echo esc_attr( $css_class ); ?>">
    <?php get_template_part( 'partials/content', 'post_details' ); ?>
</div>