<div class="item">
    <div class="step_title"><?php echo esc_html( $stm_step_title ); ?></div>
    <div class="step_description"><?php echo wp_kses_post( $stm_step_content ); ?></div>
</div>