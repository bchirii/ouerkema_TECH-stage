<div class="vacancy_bottom_wr <?php echo esc_attr( $css_class ); ?>">
    <?php get_template_part( 'partials/content', 'vacancy_bottom' ); ?>
</div>