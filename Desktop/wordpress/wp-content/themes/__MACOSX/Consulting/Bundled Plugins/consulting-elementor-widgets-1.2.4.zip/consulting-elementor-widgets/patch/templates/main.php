<div>

    <h2>PATCH</h2>

    <?php
//     $patch = new CEW_Patch(6436, 6436);
//     cew($patch->result);
    ?>

    <div id="cew_patch_app"></div>

</div>