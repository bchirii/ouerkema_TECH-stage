# Bubble UI - #CodePenChallenge: Choice UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/DeyJordan/pen/poQvgaz](https://codepen.io/DeyJordan/pen/poQvgaz).

